// Lins Shop - Etapa 2
console.log('Lins Shop carregada!');
document.querySelectorAll('a[href^="#"]').forEach(a=>{
 a.addEventListener('click',e=>{
  e.preventDefault();
  const t=document.querySelector(a.getAttribute('href'));
  if(t)t.scrollIntoView({behavior:'smooth'});
 });
});
